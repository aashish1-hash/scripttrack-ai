// ScriptScore AI — Worker. Serves /api/* ; static files come from ./public via the assets binding.
const RUBRICS = {
  short: [["Hook and opening",15],["Audience retention potential",20],["Storytelling and emotional connection",15],["Natural language and flow",10],["Information quality and factual accuracy",15],["Curiosity and engagement",10],["Ending and call to action",5],["Originality and uniqueness",10]],
  long: [["Opening and hook",15],["Structure and pacing",15],["Audience retention potential",20],["Storytelling and emotional connection",15],["Information quality and factual accuracy",15],["Clarity and natural language",10],["Ending and payoff",5],["Originality",5]]
};
const VERDICTS = [[90,"Strong Script"],[80,"Good, Minor Improvements Needed"],[70,"Needs Improvement"],[50,"Significant Problems"],[0,"Rewrite Recommended"]];
const MODES = {
  hook: "Rewrite ONLY the opening hook (first 1-3 sentences) to be stronger. Return the full script with the improved hook and everything else unchanged.",
  weak: "Fix only the weak sections: repetitive, generic, unclear, or badly transitioned lines. Leave strong parts untouched.",
  trim: "Remove unnecessary words, filler and repetition. Keep every meaningful idea. Do not add new content.",
  emotion: "Strengthen emotional connection with sensory detail and stakes, without adding invented facts.",
  retention: "Improve retention: tighter pacing, curiosity gaps, pattern interrupts, stronger transitions. Do not add invented facts.",
  rewrite: "Rewrite the entire script to be better overall."
};
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });
const norm = s => String(s || "").toLowerCase().replace(/\s+/g, " ").trim();

function parseModelJson(r) {
  const out = r?.response ?? r;
  if (out && typeof out === "object") return out;
  const m = String(out || "").match(/\{[\s\S]*\}/);
  if (!m) throw new Error("Model returned no JSON");
  return JSON.parse(m[0]);
}
const ai = (env, system, user, max) => env.AI.run(env.MODEL || "@cf/meta/llama-3.3-70b-instruct-fp8-fast", {
  messages: [{ role: "system", content: system }, { role: "user", content: user }], max_tokens: max, temperature: 0.3
});

function analyzePrompt(format, lang) {
  const cats = RUBRICS[format].map(([n, m]) => `${n} (max ${m})`).join("; ");
  return `You are a strict YouTube script editor. Script language: ${lang}. Format: ${format === "short" ? "YouTube Short" : "long video"}.
Score each category honestly (integer 0..max): ${cats}.
Quote sentences EXACTLY as written. Never state a fact is false; if a claim cannot be verified from the script itself, use type "unsupported_claim" and start the reason with "Needs verification:".
Do not promise virality. Return ONLY JSON:
{"detectedLanguage":"","categories":[{"name":"","score":0,"max":0,"explanation":""}],"hookAnalysis":"","weaknesses":[""],"issues":[{"type":"boring|unnecessary|pacing|transition|missing_context|unsupported_claim|generic_ai","quote":"","reason":"","fix":""}],"dropOffPoints":[{"quote":"","reason":""}],"strengths":[""],"recommendations":[""],"topChanges":["","",""]}`;
}

async function handleAnalyze(env, b) {
  const format = b.format === "short" ? "short" : "long";
  const d = parseModelJson(await ai(env, analyzePrompt(format, b.language || "Auto Detect"), b.script, 3500));
  const cats = RUBRICS[format].map(([name, max], i) => {
    const c = (d.categories || []).find(x => norm(x.name) === norm(name)) || d.categories?.[i] || {};
    return { name, max, score: Math.max(0, Math.min(max, Math.round(Number(c.score) || 0))), explanation: c.explanation || "" };
  });
  const total = cats.reduce((a, c) => a + c.score, 0), script = norm(b.script);
  const tag = x => ({ ...x, quoteFound: !x.quote || script.includes(norm(x.quote)) });
  return {
    format, total, verdict: VERDICTS.find(([min]) => total >= min)[1], categories: cats,
    detectedLanguage: d.detectedLanguage || "", hookAnalysis: d.hookAnalysis || "", weaknesses: d.weaknesses || [],
    issues: (d.issues || []).map(tag), dropOffPoints: (d.dropOffPoints || []).map(tag), strengths: d.strengths || [],
    recommendations: d.recommendations || [], topChanges: (d.topChanges || []).slice(0, 3),
    disclaimer: "A high score does not guarantee virality or actual audience retention."
  };
}

async function handleImprove(env, b) {
  const sys = `You are a YouTube script editor. ${MODES[b.mode]} Preserve topic, meaning, language (${b.language || "same as input"}; keep Hinglish in Roman script) and the creator's natural speaking style. Do not invent facts.${b.focus ? " Known issues: " + b.focus : ""} Return ONLY JSON: {"text":"full improved script","changes":["short note per change"]}`;
  const d = parseModelJson(await ai(env, sys, b.script, 4000));
  if (!d.text) throw new Error("Model returned empty text (JSON)");
  return { text: d.text, changes: d.changes || [] };
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (url.pathname === "/api/health") return json({ aiConfigured: !!env.AI, model: env.MODEL || "", maxChars: Number(env.MAX_CHARS) || 12000 });
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(req);
    if (req.method !== "POST") return json({ error: "Use POST." }, 405);
    if (!env.AI) return json({ error: "Workers AI binding 'AI' is not configured. See README." }, 503);
    let b;
    try { b = await req.json(); } catch { return json({ error: "Invalid JSON body." }, 400); }
    const max = Number(env.MAX_CHARS) || 12000;
    if (typeof b.script !== "string" || b.script.trim().length < 30) return json({ error: "Script is too short to analyze (minimum 30 characters)." }, 400);
    if (b.script.length > max) return json({ error: `Script is ${b.script.length} characters; the limit is ${max}. Shorten it or raise MAX_CHARS.` }, 413);
    try {
      if (url.pathname === "/api/analyze") return json(await handleAnalyze(env, b));
      if (url.pathname === "/api/improve" && MODES[b.mode]) return json(await handleImprove(env, b));
      return json({ error: "Unknown endpoint or mode." }, 404);
    } catch (e) {
      const msg = String(e?.message || e);
      if (/4006|neuron|quota|429/i.test(msg)) return json({ error: "Free Workers AI allowance appears exhausted. It resets daily at 00:00 UTC. Check usage in the Cloudflare dashboard.", detail: msg }, 429);
      if (/JSON/.test(msg)) return json({ error: "The model returned malformed output. Try again.", detail: msg }, 502);
      return json({ error: "AI request failed.", detail: msg }, 502);
    }
  }
};
