# ScriptScore AI

Personal YouTube script analyzer. Separate from ScriptFlow — no shared files.

## Architecture
```
scriptscore-ai/
├── wrangler.jsonc      Worker config: AI binding, static assets, MODEL and MAX_CHARS vars
├── package.json
├── src/worker.js       /api/health, /api/analyze, /api/improve (rubrics, validation, scoring, verdict)
└── public/             index.html, styles.css, app.js (UI, localStorage history)
```
Browser → Worker (`/api/*`) → Workers AI binding. No API tokens exist anywhere; the `AI` binding is the credential. Scores are clamped and the total and verdict are computed in code, not by the model. Quotes are checked against your script; unmatched ones are flagged.

## Deploy
1. Free Cloudflare account: https://dash.cloudflare.com/sign-up
2. `npm install` then `npx wrangler login`
3. `npx wrangler deploy` — the `ai` binding in `wrangler.jsonc` is created automatically; nothing to paste.
4. Open the printed `*.workers.dev` URL. The badge at top shows "AI ready" when the binding works.

Local test: `npx wrangler dev` (Workers AI calls always run against your Cloudflare account, even locally, and count toward usage).

## Model and free allowance
- Change `MODEL` in `wrangler.jsonc` to any text-generation model in the catalog: https://developers.cloudflare.com/workers-ai/models/ (the catalog changes; verify the ID still exists). Redeploy.
- Free-tier allowance and pricing: https://developers.cloudflare.com/workers-ai/platform/pricing/ . Your live usage: Dashboard → Workers AI. Larger models use more of the daily allowance per call. When exhausted, the app shows a clear error. Not guaranteed unlimited.
- `MAX_CHARS` (default 12000) caps script size.

## Known limits
- Analysis quality depends on the model; Hindi/Hinglish output is weaker than English. Factual claims are marked "Needs verification", never verified (no web access).
- The Improve buttons use the first analysis's issues as hints and each call sends the whole script.
- Reports live only in this browser's localStorage (last 5). Nothing is stored server-side.
