const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const KEY = "scriptscore.history.v1";
let current = null, improved = "", busy = false, maxChars = 12000;

const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; } };
const save = h => { try { localStorage.setItem(KEY, JSON.stringify(h)); } catch { msg("Could not save history (browser storage blocked).", "err"); } };
function msg(t, c = "") { $("msg").textContent = t; $("msg").className = "msg " + c; }

function counts() {
  const t = $("script").value, w = (t.trim().match(/\S+/g) || []).length, sec = Math.round(w / 2.5); // ~150 wpm
  $("words").textContent = w + " words"; $("chars").textContent = t.length + " / " + maxChars + " characters";
  $("dur").textContent = "≈ " + (sec >= 60 ? Math.floor(sec / 60) + "m " + (sec % 60) + "s" : sec + "s") + " voice-over";
}
async function api(path, body) {
  const r = await fetch(path, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({ error: "Unexpected server response." }));
  if (!r.ok) throw new Error(d.error || "Request failed (" + r.status + ")");
  return d;
}
const payload = () => ({ script: $("script").value, format: $("format").value, language: $("lang").value });
async function run(label, fn) {
  if (busy) return; busy = true; document.querySelectorAll("button").forEach(b => b.disabled = true); msg(label + "…");
  try { await fn(); msg("Done.", "ok"); } catch (e) { msg(e.message, "err"); }
  busy = false; document.querySelectorAll("button").forEach(b => b.disabled = false);
}
const list = a => `<ul>${(a || []).map(x => `<li>${esc(x)}</li>`).join("") || "<li>None found</li>"}</ul>`;

function renderReport(r) {
  current = r; improved = r.improved || "";
  const issues = (r.issues || []).map(i => `<div class="issue"><span class="tag">${esc(i.type)}</span>${i.quote ? `<q>${esc(i.quote)}</q>` : ""}${i.quote && !i.quoteFound ? `<p class="warn">Quote not found verbatim in your script.</p>` : ""}<p>${esc(i.reason)}</p>${i.fix ? `<p>Fix: ${esc(i.fix)}</p>` : ""}</div>`).join("");
  const drops = (r.dropOffPoints || []).map(i => `<div class="issue"><q>${esc(i.quote)}</q><p>${esc(i.reason)}</p></div>`).join("");
  const sec = $("report"); sec.hidden = false;
  sec.innerHTML = `<div class="score"><div class="ring" style="--p:${r.total}"><b>${r.total}</b></div><div><h2>${esc(r.verdict)}</h2><p class="msg">${r.format === "short" ? "Shorts" : "Long video"} rubric${r.detectedLanguage ? " · " + esc(r.detectedLanguage) : ""}</p></div></div>
  <h3>Change these three things before recording</h3><ol>${(r.topChanges || []).map(x => `<li>${esc(x)}</li>`).join("")}</ol>
  <h3>Category scores</h3>${r.categories.map(c => `<div class="cat"><div class="h"><span>${esc(c.name)}</span><b>${c.score}/${c.max}</b></div><div class="bar"><i style="width:${c.score / c.max * 100}%"></i></div><p>${esc(c.explanation)}</p></div>`).join("")}
  <h3>Hook analysis</h3><p>${esc(r.hookAnalysis)}</p><h3>Major weaknesses</h3>${list(r.weaknesses)}
  <h3>Problem sentences</h3>${issues || "<p class='msg'>None flagged.</p>"}<h3>Potential drop-off points</h3>${drops || "<p class='msg'>None flagged.</p>"}
  <h3>Strongest parts</h3>${list(r.strengths)}<h3>Recommendations</h3>${list(r.recommendations)}
  <p class="msg">${esc(r.disclaimer)}</p>
  <h3>Improve (runs only when you click)</h3><div class="acts">${[["hook", "Improve Hook"], ["weak", "Fix Weak Sections"], ["trim", "Remove Unnecessary Words"], ["emotion", "Improve Emotional Connection"], ["retention", "Improve Retention"], ["rewrite", "Rewrite Entire Script"]].map(([m, l]) => `<button data-mode="${m}">${l}</button>`).join("")}<button id="copyReport">Copy Report</button><button id="copyImp">Copy Improved Script</button></div><div id="impBox"></div>`;
  showImproved(r.changes);
  sec.querySelectorAll("[data-mode]").forEach(b => b.onclick = () => improve(b.dataset.mode, b.textContent));
  $("copyReport").onclick = () => copy(reportText(r), "Report copied.");
  $("copyImp").onclick = () => improved ? copy(improved, "Improved script copied.") : msg("Nothing improved yet. Use an improve button first.", "err");
}
function showImproved(ch) {
  $("impBox").innerHTML = improved ? `<h3>Improved script</h3><div class="improved">${esc(improved)}</div>${(ch || []).length ? list(ch) : ""}` : "";
}
function reportText(r) {
  return `ScriptScore AI: ${r.total}/100 (${r.verdict})\n\n` + r.categories.map(c => `${c.name}: ${c.score}/${c.max} - ${c.explanation}`).join("\n") +
    `\n\nTop changes:\n` + (r.topChanges || []).map((x, i) => `${i + 1}. ${x}`).join("\n") + `\n\nHook: ${r.hookAnalysis}\n\nWeaknesses:\n- ` + (r.weaknesses || []).join("\n- ") +
    `\n\nIssues:\n` + (r.issues || []).map(i => `[${i.type}] "${i.quote}" - ${i.reason}`).join("\n") + `\n\nStrengths:\n- ` + (r.strengths || []).join("\n- ") + `\n\nRecommendations:\n- ` + (r.recommendations || []).join("\n- ") + `\n\n${r.disclaimer}`;
}
async function copy(t, ok) { try { await navigator.clipboard.writeText(t); msg(ok, "ok"); } catch { msg("Clipboard blocked by the browser.", "err"); } }

function persist() { if (!current) return; save([{ ...current, improved }, ...load().filter(x => x.id !== current.id)].slice(0, 5)); renderHist(); }
function renderHist() {
  const h = load();
  $("hist").innerHTML = h.length ? h.map(x => `<li><span>${new Date(x.id).toLocaleString()} · <b>${x.total}</b>/100 · ${esc((x.script || "").slice(0, 40))}…</span><span><button data-o="${x.id}">Open</button> <button data-d="${x.id}">Delete</button></span></li>`).join("") : "<li class='msg'>No saved reports yet.</li>";
  $("hist").querySelectorAll("[data-o]").forEach(b => b.onclick = () => { const x = load().find(y => y.id == b.dataset.o); if (x) { $("script").value = x.script; $("format").value = x.format; counts(); renderReport(x); } });
  $("hist").querySelectorAll("[data-d]").forEach(b => b.onclick = () => { save(load().filter(y => y.id != b.dataset.d)); renderHist(); });
}

$("script").oninput = counts;
$("clear").onclick = () => { $("script").value = ""; counts(); };
$("paste").onclick = async () => { try { $("script").value = await navigator.clipboard.readText(); counts(); } catch { msg("Clipboard blocked. Paste with Ctrl/Cmd+V.", "err"); } };
$("clearAll").onclick = () => { if (confirm("Delete all saved reports?")) { save([]); renderHist(); } };
$("analyze").onclick = () => run("Analyzing", async () => { const p = payload(), r = await api("/api/analyze", p); renderReport({ ...r, id: Date.now(), script: p.script }); persist(); });
function improve(mode, label) {
  run(label, async () => {
    const focus = (current.issues || []).slice(0, 6).map(i => i.reason).join("; ");
    const d = await api("/api/improve", { ...payload(), mode, focus });
    improved = d.text; current.improved = d.text; current.changes = d.changes; showImproved(d.changes); persist();
  });
}
(async () => {
  counts(); renderHist();
  try {
    const h = await (await fetch("/api/health")).json(); maxChars = h.maxChars || maxChars; counts();
    $("status").textContent = h.aiConfigured ? "AI ready · " + (h.model || "").split("/").pop() : "AI binding missing";
    $("status").className = "pill " + (h.aiConfigured ? "ok" : "err");
  } catch { $("status").textContent = "Backend unreachable (use wrangler dev or deploy)"; $("status").className = "pill err"; }
})();
